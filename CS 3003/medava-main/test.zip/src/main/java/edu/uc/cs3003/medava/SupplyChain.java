package edu.uc.cs3003.medava;

public class SupplyChain {
    public static void main(String args[]) {
        // System.out.println("Hello, Nathan! This is the WOPR speaking.");

        HospitalRunner.run();
    }
}
